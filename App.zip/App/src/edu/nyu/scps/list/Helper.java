package edu.nyu.scps.list;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import android.widget.Toast;

public class Helper extends SQLiteOpenHelper{
	Context context;

	private static final String insert_str = "insert into notes ( note) values (?)";
	public Helper(Context context) {
		super(context, "notes.db", null, 2); 
		this.context = context;
		SQLiteDatabase db = getWritableDatabase();
		db.execSQL("CREATE TABLE notes ("
				+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ "note TEXT"
				+ ")");
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		//an array of five strings
		/*
		String statements[] = {
			"CREATE TABLE notes ("
				+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ "note TEXT"
				+ ");",
			
				
		};
		
		for (String statement: statements) {
			db.execSQL(statement);
		}
		*/
		
		db.execSQL("CREATE if not exist TABLE notes ("
				+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ "note TEXT"
				+ ")");
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
	
	
	public void addNote(String note){
		Log.d("List", "note = " + note);
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement insertstmt = db.compileStatement(insert_str);
		insertstmt.bindString(1, note);
		insertstmt.executeInsert();
		Log.d("List", "note added");
	}
	
	
	public void showNotes() {
		String sql = "SELECT * FROM notes;";
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);

		String notes = "";
		Log.d("List", "outside the cursor");
		if (cursor.moveToFirst()) {
			Log.d("List", "inside the cursor " + cursor.getString(1));
			do {
				notes += "" + cursor.getString(1) + "\n";
			} while (cursor.moveToNext());
		}
		Toast.makeText(context, notes, Toast.LENGTH_LONG).show();
		
	}
}
