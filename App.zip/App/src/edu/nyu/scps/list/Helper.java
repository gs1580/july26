package edu.nyu.scps.list;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class Helper extends SQLiteOpenHelper{
	Context context;

	public Helper(Context context) {
		super(context, "notes.db", null, 2); 
		this.context = context;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		//an array of five strings
		String statements[] = {
			"CREATE TABLE notes ("
				+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ "note TEXT"
				+ ");",
			
				"INSERT INTO notes (_id, note) VALUES (NULL, 'check');",

		};
		
		for (String statement: statements) {
			db.execSQL(statement);
		}
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
	
	
	public void addNote(String note){
		String sql = "INSERT INTO notes (_id, note) VALUES (NULL,\'" + note + "\')";
		SQLiteDatabase db = getReadableDatabase();
		db.rawQuery(sql, null);
		Log.d("List", "note added");
	}
	
	
	public void showNotes() {
		String sql = "SELECT * FROM notes;";
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);

		String notes = "";
		Log.d("List", "outside the cursor");
		if (cursor.moveToFirst()) {
			Log.d("List", "inside the cursor");
			do {
				notes += " " + cursor.getString(1);
			} while (cursor.moveToNext());
		}
		Toast.makeText(context, notes, Toast.LENGTH_LONG).show();

	}
}
