package edu.nyu.scps.list;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class List extends Activity{ 
	/** Called when the activity is first created. */

	Helper helper = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		helper = new Helper(this);
		setContentView(R.layout.main); 
	         
		final EditText  editView = (EditText)findViewById(R.id.edittext);
		 
		final Button saveButton = (Button)findViewById(R.id.savebutton); 
	       
		saveButton.setOnClickListener(new OnClickListener() {
	            public void onClick(View v) {
	            	showToast(List.this, "Saving to database: " + editView.getText());
	            	helper.addNote("" + editView.getText());
	           }
	        });
		
		final Button showButton = (Button)findViewById(R.id.showbutton);
	       
		showButton.setOnClickListener(new OnClickListener() {
	            public void onClick(View v) {
	            	helper.showNotes();
	           }
	        });
	}

	private void showToast(Context context, CharSequence msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
}